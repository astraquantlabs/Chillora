#!/usr/bin/env python3
"""Compose the Chillora share card from the existing moon wordmark.

Image generation is unavailable (quota). The card is built from the real
crescent / stars / clouds / Chillora mark so the wordmark stays exact.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path("/workspace/.grok")
LOGO = Path("/workspace/attachments/1000586291.jpg")
OUT = ROOT / "card-raw.png"

# Brand tokens
NAVY = np.array([7, 11, 24], dtype=np.float32)  # #070B18
LOGO_NAVY = np.array([7, 9, 50], dtype=np.float32)  # plate behind the mark
LAV = np.array([212, 194, 245], dtype=np.float32)  # #D4C2F5
PEACH = np.array([240, 184, 164], dtype=np.float32)  # #F0B8A4
MIST = np.array([142, 180, 216], dtype=np.float32)  # #8EB4D8
CREAM = np.array([244, 240, 232], dtype=np.float32)  # #F4F0E8

W, H = 2400, 1260  # 2× 1200×630, normalized later


def key_logo() -> Image.Image:
    src = Image.open(LOGO).convert("RGB")
    arr = np.asarray(src).astype(np.float32)
    dist = np.linalg.norm(arr - LOGO_NAVY, axis=2)
    lo, hi = 12.0, 46.0
    alpha = np.clip((dist - lo) / (hi - lo), 0, 1)
    # Pull the keyed fringe from the logo's bluer plate toward brand navy
    # so partial pixels don't leave a cyan rim on the card.
    a = alpha[..., None]
    arr = arr + (NAVY - LOGO_NAVY) * (1.0 - a)
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    a_img = Image.fromarray((alpha * 255).astype(np.uint8), mode="L")
    a_img = a_img.filter(ImageFilter.GaussianBlur(radius=0.45))
    rgba = Image.fromarray(arr, mode="RGB").convert("RGBA")
    rgba.putalpha(a_img)
    bbox = a_img.point(lambda p: 255 if p > 18 else 0).getbbox()
    if not bbox:
        raise SystemExit("logo key produced an empty mark")
    # Small pad so antialiased tips of stars survive the crop.
    x0, y0, x1, y1 = bbox
    pad = 10
    x0, y0 = max(0, x0 - pad), max(0, y0 - pad)
    x1, y1 = min(rgba.width, x1 + pad), min(rgba.height, y1 + pad)
    return rgba.crop((x0, y0, x1, y1))


def blob(h: int, w: int, cx: float, cy: float, rx: float, ry: float) -> np.ndarray:
    ys, xs = np.mgrid[0:h, 0:w]
    dx = (xs - cx) / rx
    dy = (ys - cy) / ry
    return np.exp(-(dx * dx + dy * dy))


def paint_sky() -> Image.Image:
    ys, xs = np.mgrid[0:H, 0:W]
    # Deep field, slightly lifted toward indigo behind the lockup.
    cx, cy = W * 0.50, H * 0.46
    r = np.sqrt(((xs - cx) / (W * 0.62)) ** 2 + ((ys - cy) / (H * 0.78)) ** 2)
    center = np.clip(1.0 - r, 0, 1) ** 1.35
    sky = NAVY[None, None, :] + (LOGO_NAVY - NAVY)[None, None, :] * (center[..., None] * 0.92)
    # Soft lavender halo where the moon sits.
    sky += (LAV - sky) * (blob(H, W, W * 0.50, H * 0.36, W * 0.22, H * 0.34)[..., None] * 0.10)
    # Peach dusk along the lower left, mist along the lower right.
    sky += (PEACH - sky) * (blob(H, W, W * 0.18, H * 0.92, W * 0.34, H * 0.28)[..., None] * 0.16)
    sky += (MIST - sky) * (blob(H, W, W * 0.86, H * 0.78, W * 0.30, H * 0.36)[..., None] * 0.12)
    sky += (LAV - sky) * (blob(H, W, W * 0.08, H * 0.22, W * 0.16, H * 0.20)[..., None] * 0.08)
    # Vignette
    vx = (xs / (W - 1) - 0.5) * 2
    vy = (ys / (H - 1) - 0.5) * 2
    vig = np.clip(vx * vx * 0.55 + vy * vy * 0.85, 0, 1) ** 1.4
    sky = sky * (1 - vig[..., None] * 0.45) + NAVY * (vig[..., None] * 0.45)
    sky = np.clip(sky, 0, 255).astype(np.uint8)
    return Image.fromarray(sky, mode="RGB")


def add_stars(base: Image.Image) -> Image.Image:
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    rng = np.random.default_rng(7)

    def sparkle(x: float, y: float, r: float, color: tuple[int, int, int], alpha: int) -> None:
        # Four long rays + four short diagonals. Flat, no fake lens dirt.
        col = (*color, alpha)
        soft = (*color, int(alpha * 0.35))
        draw.line((x - r, y, x + r, y), fill=soft, width=max(2, int(r * 0.18)))
        draw.line((x, y - r, x, y + r), fill=soft, width=max(2, int(r * 0.18)))
        d = r * 0.42
        draw.line((x - d, y - d, x + d, y + d), fill=col, width=max(2, int(r * 0.12)))
        draw.line((x - d, y + d, x + d, y - d), fill=col, width=max(2, int(r * 0.12)))
        core = max(2, int(r * 0.22))
        draw.ellipse((x - core, y - core, x + core, y + core), fill=(*color, min(255, alpha + 30)))

    # Keep the lockup clear: stars live in the side margins.
    placed = 0
    attempts = 0
    while placed < 42 and attempts < 800:
        attempts += 1
        x = float(rng.uniform(40, W - 40))
        y = float(rng.uniform(36, H - 50))
        # Central lockup (moon + wordmark) stays the only dense cluster.
        if (W * 0.30) < x < (W * 0.70) and (H * 0.08) < y < (H * 0.92):
            continue
        roll = float(rng.random())
        if roll < 0.08:
            color = (int(PEACH[0]), int(PEACH[1]), int(PEACH[2]))
        elif roll < 0.28:
            color = (int(LAV[0]), int(LAV[1]), int(LAV[2]))
        elif roll < 0.45:
            color = (int(MIST[0]), int(MIST[1]), int(MIST[2]))
        else:
            color = (int(CREAM[0]), int(CREAM[1]), int(CREAM[2]))
        r = float(rng.uniform(2.2, 7.5))
        alpha = int(rng.integers(140, 230))
        if roll > 0.82:
            sparkle(x, y, r * 2.4, color, alpha)
        else:
            draw.ellipse((x - r, y - r, x + r, y + r), fill=(*color, alpha))
        placed += 1

    # Two quiet hero sparkles in the open sky, echoing the mark's star.
    sparkle(W * 0.16, H * 0.30, 22, (244, 240, 232), 210)
    sparkle(W * 0.84, H * 0.24, 16, (212, 194, 245), 190)
    sparkle(W * 0.78, H * 0.62, 11, (240, 184, 164), 160)

    blurred = overlay.filter(ImageFilter.GaussianBlur(radius=0.6))
    out = base.convert("RGBA")
    out.alpha_composite(blurred)
    return out


def main() -> None:
    mark = key_logo()
    sky = add_stars(paint_sky())
    # Lockup fills most of the height with comfortable margins (not edge-hugging).
    target_h = int(H * 0.82)
    scale = target_h / mark.height
    target_w = max(1, int(round(mark.width * scale)))
    mark = mark.resize((target_w, target_h), Image.Resampling.LANCZOS)
    x = (W - target_w) // 2
    y = (H - target_h) // 2 - int(H * 0.01)
    # A faint contact glow so the mark sits in the sky rather than floating as a sticker.
    glow = Image.new("RGBA", sky.size, (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    g.ellipse(
        (x + target_w * 0.18, y + target_h * 0.08, x + target_w * 0.82, y + target_h * 0.62),
        fill=(212, 194, 245, 28),
    )
    glow = glow.filter(ImageFilter.GaussianBlur(radius=48))
    sky.alpha_composite(glow)
    sky.alpha_composite(mark, (x, y))
    rgb = sky.convert("RGB")
    rgb.save(OUT, format="PNG", optimize=True)
    print(f"wrote {OUT} {rgb.size} mark={mark.size} at {(x, y)}")


if __name__ == "__main__":
    main()
