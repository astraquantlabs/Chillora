import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Moon, c as Check, i as Search, l as ArrowUpRight, o as Link2, r as Shield, s as Copy, t as Users } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D_WG8-x8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var chillora_logo_default = "/assets/chillora-logo-C8Guuac_.jpg";
var DISCORD_URL = "https://discord.gg/W4PJVKRUVP";
var INVITE_CODE = "W4PJVKRUVP";
var EFFECTIVE = "7 November 2026";
var rules = [
	{
		id: "rule-01",
		n: "01",
		group: "The room",
		title: "Keep the vibe easy",
		body: "Chillora is a low-pressure hangout. Don’t pick fights, pile on, or stretch a joke until someone has to leave. If a thread is getting sharp, drop it or call a moderator. Winning the argument is not the point of being here."
	},
	{
		id: "rule-02",
		n: "02",
		group: "The room",
		title: "Talk to people, not at them",
		body: "Disagree with what someone said, not with who they are. Slurs, dogwhistles, identity bait, and “it’s just a joke” harassment are the same thing here. One warning is generous. A pattern is a removal."
	},
	{
		id: "rule-03",
		n: "03",
		group: "The room",
		title: "Read the channel before you post",
		body: "Each channel has a job. Check the topic and the pins. Off-topic walls, copypasta floods, and dropping the same message in several channels count as spam even if each post looks harmless on its own."
	},
	{
		id: "rule-04",
		n: "04",
		group: "Safety",
		title: "Nothing illegal, and nothing that exploits a minor",
		body: "Zero tolerance. That includes sexual content involving anyone under 18, credible threats, doxxing, and posting someone’s private information — address, phone, workplace, legal name they didn’t share, or photos they didn’t put here. We remove it, ban the account, and report it when Discord or the law requires that."
	},
	{
		id: "rule-05",
		n: "05",
		group: "Safety",
		title: "Keep sexual and shock content out",
		body: "No NSFW, gore, or shock media in messages, images, voice, nicknames, statuses, or custom emoji. There is no age-gated channel that waives this. If you have to ask whether it belongs, it doesn’t."
	},
	{
		id: "rule-06",
		n: "06",
		group: "Safety",
		title: "No scams, phishing, or cold DMs",
		body: "No Nitro scams, crypto pumps, malware links, or unsolicited DMs to members you don’t already know. If a link looks off, don’t click it — tell staff. Starting a DM from this server still counts as being in Chillora."
	},
	{
		id: "rule-07",
		n: "07",
		group: "Safety",
		title: "You must be 13 or older",
		body: "Discord’s terms set the floor, and we follow it. Don’t lie about your age. If you are under 18, don’t share identifying details. Staff may limit voice or other features when that keeps younger members safer."
	},
	{
		id: "rule-08",
		n: "08",
		group: "Voice and chat",
		title: "Voice is a shared room",
		body: "No ear-rape, soundboards over people, or music unless that channel is for it. Don’t record anyone without a clear yes. If you need a private call, take it somewhere else. An open mic with shouting in the background is still you talking."
	},
	{
		id: "rule-09",
		n: "09",
		group: "Voice and chat",
		title: "Write so the room can follow",
		body: "Use the language of the channel you’re in. Don’t flip a public channel into a side conversation meant to shut someone out. Slurs don’t become allowed because they’re in another language."
	},
	{
		id: "rule-10",
		n: "10",
		group: "Accounts",
		title: "One person, one account",
		body: "No alternate accounts to dodge a timeout, mute, or ban. Ban evasion applies to every account we can tie to you. Sharing an account, or handing your login to someone else, is your responsibility if that account breaks a rule."
	},
	{
		id: "rule-11",
		n: "11",
		group: "Accounts",
		title: "Self-promo is opt-in only",
		body: "No server invites, referral links, streams, or “check my page” drops unless the channel explicitly allows them. Asking a moderator first is faster than watching the message disappear. Unsolicited promo in DMs is still promo."
	},
	{
		id: "rule-12",
		n: "12",
		group: "Accounts",
		title: "Don’t automate the room",
		body: "Don’t add bots, fire webhooks, or mass-mention people. @everyone and @here are for staff. Reaction spam, mention chains, and macro floods are timeouts even when you think they’re funny."
	},
	{
		id: "rule-13",
		n: "13",
		group: "Staff",
		title: "Moderator calls stand",
		body: "Timeouts, kicks, and bans exist to protect the room, not to score a point. You may appeal once, calmly, through the path staff give you. Arguing a punishment in public, or dogpiling a moderator, is its own violation."
	},
	{
		id: "rule-14",
		n: "14",
		group: "Staff",
		title: "Discord’s rules still apply",
		body: "These rules sit on top of the Discord Terms of Service and Community Guidelines. Breaking those is breaking ours. Staff can act on context the message alone doesn’t show — raid timing, prior warnings, and reports from members."
	}
];
var terms = [
	{
		id: "term-01",
		n: "01",
		title: "Agreement",
		paragraphs: ["By joining Chillora, staying in the server, or posting in it, you agree to these terms, the server rules, and the rights articles on this page. If you don’t agree, leave. The invite is part of the server, not a separate product.", "Continuing to participate after we post a change is agreement to that change. The date at the top of this page is the version that applies."]
	},
	{
		id: "term-02",
		n: "02",
		title: "What Chillora is",
		paragraphs: ["Chillora is a volunteer-run Discord community. It is not a company, not a paid service, and not affiliated with Discord Inc. We don’t sell memberships, ranks, or protection.", "Moderators are members with extra permissions. They are not your lawyer, therapist, or emergency service. If you are in danger, contact local emergency services — don’t wait on a ticket."]
	},
	{
		id: "term-03",
		n: "03",
		title: "Who can join",
		paragraphs: ["You need a Discord account that is allowed to use Discord: at least 13 years old, and not banned from the platform. We can refuse entry or remove you when that protects the server, including during a raid, a full server, or a history we don’t want in the room.", "Joining is a privilege, not a right. An open invite is not a promise that every account will be kept."]
	},
	{
		id: "term-04",
		n: "04",
		title: "Your messages and media",
		paragraphs: ["You keep ownership of what you post. You give the Chillora moderators permission to display that content inside the server, and to remove, hide, or report it. Don’t post anything you don’t have the right to share.", "We don’t promise to store your messages. Discord holds them under its own terms. Moderators may delete messages as part of keeping the room usable, with or without a copy kept for the appeal."]
	},
	{
		id: "term-05",
		n: "05",
		title: "How we moderate",
		paragraphs: ["Staff may warn, timeout, kick, ban, delete messages, remove reactions, reset nicknames, or close channels. Severe cases — illegal content, raids, doxxing, harassment, scams — can skip straight to a ban.", "We don’t owe you a public debate, a full transcript, or a fixed response time. Appeals are one calm message through the path staff publish. Repeat or bad-faith appeals can be ignored."]
	},
	{
		id: "term-06",
		n: "06",
		title: "Your responsibilities",
		paragraphs: ["You are responsible for your account, the invites you share, and what you send, including direct messages you start because of this server. Don’t use Chillora to harm anyone, break the law, or get around a Discord punishment.", "If you see something dangerous, tell a moderator or use Discord’s report tools. Don’t “handle it” by leaking private messages into a public channel."]
	},
	{
		id: "term-07",
		n: "07",
		title: "No warranties",
		paragraphs: ["The server is provided as-is. Channels can go quiet, bots can break, and we can archive, rename, or delete the community. We are not liable for another member’s opinions, for lost messages, or for anything someone sends you.", "Nothing in the server is professional, medical, legal, or financial advice — including when a member sounds sure."]
	},
	{
		id: "term-08",
		n: "08",
		title: "Liability",
		paragraphs: ["To the extent the law allows, Chillora and its staff are not liable for indirect or consequential damages arising from your use of the server. Some places don’t allow that kind of limit. Where they don’t, the limit applies only as far as it legally can.", "This section does not limit liability for anything the law says cannot be limited."]
	},
	{
		id: "term-09",
		n: "09",
		title: "Privacy",
		paragraphs: ["Chillora does not run its own account system and does not ask you to verify with a government ID. Discord holds your account data under Discord’s privacy policy.", "Moderators can see what Discord shows them: messages, joins, the audit log of actions we take, and reports members send us. Don’t post secrets you wouldn’t want a moderator to read. We don’t sell member data. We don’t run ads off it."]
	},
	{
		id: "term-10",
		n: "10",
		title: "Changes and the live server",
		paragraphs: ["We can update the rules or these terms by posting the new version in the server and on this page. Larger changes will be announced in an announcements channel when one exists.", "If this page and a pinned message in the server ever disagree, the live server is the source of truth until this page is updated. Discord’s own terms always apply alongside ours, and they win if the two conflict."]
	}
];
var spirit = [
	"Assume good faith once. Not twice, if it’s clearly bait.",
	"Leave a conversation cleaner than you found it.",
	"If you wouldn’t say it on mic, don’t type it.",
	"Ask a moderator before you guess. Guessing is how people get timed out."
];
var articles = [
	{
		id: "art-01",
		n: "01",
		role: "Members",
		title: "The same rules for everyone",
		body: "Every member is entitled to the same rules. Rank, age in the server, or being friends with staff does not create a private exception. Harassment, slurs, scams, and illegal content are violations no matter who posts them."
	},
	{
		id: "art-02",
		n: "02",
		role: "Members",
		title: "Use of the room",
		body: "Members may read and post in the channels their role can see, join open voice channels, and leave a conversation without being followed or piled on. Access to a channel is not a promise that every message stays up."
	},
	{
		id: "art-03",
		n: "03",
		role: "Members",
		title: "Notice before an ordinary punishment",
		body: "For an ordinary miss, a member is entitled to know which rule was broken before a timeout, kick, or ban. That notice can be a short message. It does not apply when the enforcement section says the case skips straight to a ban."
	},
	{
		id: "art-04",
		n: "04",
		role: "Members",
		title: "One appeal",
		body: "A punished member may appeal once, in private, through the path staff publish. They are entitled to a yes or a no. They are not entitled to a public vote, a second appeal, or a running argument in general chat."
	},
	{
		id: "art-05",
		n: "05",
		role: "Members",
		title: "Life outside the server",
		body: "Members are entitled to keep off-server life off-server. Nobody may demand a legal name, post a home address, share private photos, or paste direct messages the other person did not agree to share."
	},
	{
		id: "art-06",
		n: "06",
		role: "Members",
		title: "Leaving",
		body: "A member may leave at any time. There is no fee, no rank to cash out, and no lock on the account. Leaving does not erase a ban, and it does not entitle anyone to a copy of deleted messages."
	},
	{
		id: "art-07",
		n: "07",
		role: "Staff",
		title: "Power to moderate",
		body: "Staff may warn, delete messages, remove reactions, reset a nickname, timeout, kick, and ban, inside these rules and the enforcement ladder. They may close a thread that has stopped being a conversation."
	},
	{
		id: "art-08",
		n: "08",
		role: "Staff",
		title: "What staff may see",
		body: "Staff may use the moderator view Discord gives them: reports, the audit log of actions they take, and messages needed to judge a case. That access is for moderation. It is not for gossip, screenshots in other servers, or personal curiosity."
	},
	{
		id: "art-09",
		n: "09",
		role: "Staff",
		title: "Protection while on duty",
		body: "A member may not threaten, dogpile, or harass staff for making a call. Disagreement goes through the one appeal. Staff may mute a pile-on without opening a new debate about whether they were allowed to mute it."
	},
	{
		id: "art-10",
		n: "10",
		role: "Staff",
		title: "Limits on the role",
		body: "Staff may not punish someone to win a personal argument, sell roles, leak a private report, or skip a rule for a friend. A manager can remove the staff role for that. The person returns to member status and keeps only member rights."
	},
	{
		id: "art-11",
		n: "11",
		role: "Staff",
		title: "Stepping down",
		body: "Staff may resign at any time and go back to being a member. Resignation is effective when a manager or the owner removes the role. Past moderation actions stay in effect unless a manager overturns them."
	},
	{
		id: "art-12",
		n: "12",
		role: "Managers",
		title: "Authority over staff",
		body: "Managers sit above staff. They may appoint staff, remove staff, settle a dispute between staff, and overturn a staff action that broke these articles or the rules. They do not need a public vote to do it."
	},
	{
		id: "art-13",
		n: "13",
		role: "Managers",
		title: "Care of the server",
		body: "Managers may edit channels, roles below their own, and pins that state policy, and they may update the public copy of this charter. They may not sell the server, transfer ownership, or promise a paid deal unless the owner agrees in writing in the server."
	},
	{
		id: "art-14",
		n: "14",
		role: "Managers",
		title: "No immunity",
		body: "A manager is still a member. The rules on harassment, scams, sexual content, and anything illegal apply with no exception. Rank is not a defense, and staff may log a report against a manager for a manager or the owner to judge."
	},
	{
		id: "art-15",
		n: "15",
		role: "Managers",
		title: "Who answers an appeal",
		body: "An appeal about a staff action is answered by a manager. An appeal about a manager is answered by a different manager or by the owner. One answer stands. The person who made the original punishment does not judge their own appeal."
	},
	{
		id: "art-16",
		n: "16",
		role: "Managers",
		title: "Changes to these rights",
		body: "A manager may not quietly delete these articles. A change is real only when it is posted on this page and announced in the server, the same way the terms say changes are posted. Until that happens, the published articles apply."
	}
];
var ladder = [
	{
		n: "1",
		title: "Reminder",
		body: "A short note, in channel or in DMs, for a first small miss."
	},
	{
		n: "2",
		title: "Warning",
		body: "Logged. The next one is a punishment, not another conversation."
	},
	{
		n: "3",
		title: "Timeout",
		body: "You stay in the server but can’t talk. Usually an hour up to seven days."
	},
	{
		n: "4",
		title: "Kick",
		body: "You’re removed. Rejoining is only possible if the invite is open and the kick wasn’t a “don’t come back.”"
	},
	{
		n: "5",
		title: "Ban",
		body: "You’re out. A new account does not reset it."
	}
];
var toc = [
	{
		id: "spirit",
		label: "Spirit"
	},
	{
		id: "rules",
		label: "Rules"
	},
	{
		id: "rights",
		label: "Rights"
	},
	{
		id: "terms",
		label: "Terms"
	},
	{
		id: "enforcement",
		label: "Enforcement"
	},
	{
		id: "contact",
		label: "Contact"
	}
];
function useActiveSection(ids) {
	const [active, setActive] = (0, import_react.useState)(ids[0] ?? "");
	(0, import_react.useEffect)(() => {
		const nodes = ids.map((id) => document.getElementById(id)).filter((node) => node !== null);
		if (nodes.length === 0) return;
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			rootMargin: "-30% 0px -55% 0px",
			threshold: [.15, .4]
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, [ids]);
	return active;
}
var sectionIds = toc.map((item) => item.id);
function CharterPage() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)("idle");
	const active = useActiveSection(sectionIds);
	const needle = query.trim().toLowerCase();
	const visibleRules = (0, import_react.useMemo)(() => {
		if (!needle) return rules;
		return rules.filter((rule) => `${rule.n} ${rule.group} ${rule.title} ${rule.body}`.toLowerCase().includes(needle));
	}, [needle]);
	const visibleTerms = (0, import_react.useMemo)(() => {
		if (!needle) return terms;
		return terms.filter((term) => `${term.title} ${term.paragraphs.join(" ")}`.toLowerCase().includes(needle));
	}, [needle]);
	const visibleArticles = (0, import_react.useMemo)(() => {
		if (!needle) return articles;
		return articles.filter((article) => `${article.n} ${article.role} ${article.title} ${article.body}`.toLowerCase().includes(needle));
	}, [needle]);
	const articleRoles = (0, import_react.useMemo)(() => {
		const order = [];
		for (const article of visibleArticles) if (!order.includes(article.role)) order.push(article.role);
		return order;
	}, [visibleArticles]);
	const groups = (0, import_react.useMemo)(() => {
		const order = [];
		for (const rule of visibleRules) if (!order.includes(rule.group)) order.push(rule.group);
		return order;
	}, [visibleRules]);
	async function copyInvite() {
		let ok = false;
		try {
			await navigator.clipboard.writeText(DISCORD_URL);
			ok = true;
		} catch {
			const field = document.createElement("textarea");
			field.value = DISCORD_URL;
			field.setAttribute("readonly", "");
			field.style.position = "fixed";
			field.style.left = "0";
			field.style.top = "0";
			field.style.opacity = "0";
			document.body.appendChild(field);
			field.focus();
			field.select();
			try {
				ok = document.execCommand("copy");
			} catch {
				ok = false;
			}
			field.remove();
		}
		setCopied(ok ? "done" : "failed");
		window.setTimeout(() => setCopied("idle"), 2e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#spirit",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-surface focus:px-4 focus:py-2",
				children: "Skip to the charter"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/85 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: chillora_logo_default,
								alt: "",
								className: "h-10 w-10 rounded-full object-cover ring-1 ring-line"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate font-display text-lg text-fg",
								children: "Chillora"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "ml-auto hidden items-center gap-1 lg:flex",
							"aria-label": "On this page",
							children: toc.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `#${item.id}`,
								className: `rounded-full px-3 py-2 text-sm ${active === item.id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"}`,
								"aria-current": active === item.id ? "true" : void 0,
								children: item.label
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: DISCORD_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "ml-auto inline-flex h-11 items-center gap-2 rounded-full bg-peach px-4 text-sm font-medium text-bg lg:ml-3",
							children: ["Join", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
								className: "h-4 w-4",
								"aria-hidden": "true"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex gap-2 overflow-x-auto px-4 pb-3 lg:hidden",
					"aria-label": "On this page",
					children: toc.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `#${item.id}`,
						className: `shrink-0 rounded-full border px-3 py-2 text-sm ${active === item.id ? "border-moon bg-surface-2 text-fg" : "border-line text-muted"}`,
						children: item.label
					}, item.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				id: "top",
				className: "mx-auto grid max-w-6xl gap-10 px-4 py-8 sm:px-6 sm:py-12 lg:grid-cols-12 lg:gap-14 lg:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "hidden lg:col-span-3 lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sticky top-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-moon uppercase",
								children: "On this page"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-4 space-y-1 border-l border-line",
								children: toc.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `#${item.id}`,
									className: `block border-l-2 py-2 pl-4 text-sm ${active === item.id ? "-ml-px border-peach text-fg" : "border-transparent text-muted hover:text-fg"}`,
									"aria-current": active === item.id ? "location" : void 0,
									children: item.label
								}) }, item.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-8 text-sm text-muted",
								children: [
									"Version ",
									"1.1",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									EFFECTIVE
								]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 lg:col-span-9",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "night-mast rounded-3xl border border-line bg-bg-soft px-5 py-8 sm:px-8 sm:py-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-start gap-6 sm:flex-row sm:items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: chillora_logo_default,
									alt: "Chillora — crescent moon over clouds",
									className: "w-40 rounded-3xl ring-1 ring-line sm:w-48"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs tracking-widest text-moon uppercase",
											children: "Discord community charter"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
											className: "mt-2 font-display text-4xl leading-none text-fg sm:text-5xl",
											children: [
												"Rules ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-peach italic",
													children: "&"
												}),
												" terms"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 max-w-xl text-base text-muted sm:text-lg",
											children: "The house rules for Chillora. Joining the server, or staying in it, means you have read this and agree to it."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-6 flex flex-col gap-3 sm:flex-row",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: DISCORD_URL,
												target: "_blank",
												rel: "noreferrer",
												className: "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-peach px-5 text-sm font-medium text-bg",
												children: ["Join the server", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
													className: "h-4 w-4",
													"aria-hidden": "true"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: copyInvite,
												className: "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-surface px-5 text-sm text-fg",
												children: [copied === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
													className: "h-4 w-4 text-moon",
													"aria-hidden": "true"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
													className: "h-4 w-4 text-moon",
													"aria-hidden": "true"
												}), copied === "done" ? "Invite copied" : copied === "failed" ? "Copy blocked" : "Copy invite"]
											})]
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-8 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Effective ", EFFECTIVE] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Version ", "1.1"] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-mist",
										children: INVITE_CODE
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "spirit",
							className: "mt-12",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {
										className: "h-5 w-5 text-moon",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-3xl text-fg",
										children: "The spirit"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-muted",
									children: "Chillora works when people act like guests in a quiet room. The numbered rules below are how we enforce that. These four lines are the reason they exist."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-6 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface",
									children: spirit.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "px-5 py-4 text-fg sm:px-6",
										children: line
									}, line))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "rules",
							className: "mt-14",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl text-fg",
									children: "Server rules"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-muted",
									children: [
										visibleRules.length,
										" of ",
										rules.length,
										" rules",
										needle ? " match your search" : ", in the order staff cite them",
										"."
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "relative block w-full sm:w-72",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Search rules and terms"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
											className: "pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: query,
											onChange: (event) => setQuery(event.target.value),
											placeholder: "Search voice, ban, promo…",
											className: "h-11 w-full rounded-full border border-line bg-surface pr-4 pl-10 text-sm text-fg placeholder:text-muted"
										})
									]
								})]
							}), visibleRules.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-8 rounded-2xl border border-line bg-surface px-5 py-8 text-muted",
								children: [
									"Nothing in the rules matches “",
									query.trim(),
									"”. Try voice, ban, scam, or promo."
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 space-y-10",
								children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs tracking-widest text-mist uppercase",
									children: group
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-3 divide-y divide-line border-t border-line",
									children: visibleRules.filter((rule) => rule.group === group).map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										id: rule.id,
										className: "flex gap-4 py-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: `#${rule.id}`,
											className: "w-12 shrink-0 font-display text-xl text-moon",
											"aria-label": `Rule ${rule.n}`,
											children: rule.n
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-lg font-medium text-fg",
												children: rule.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-muted",
												children: rule.body
											})]
										})]
									}, rule.id))
								})] }, group))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "rights",
							className: "mt-16",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
										className: "h-5 w-5 text-moon",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-3xl text-fg",
										children: "Rights"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-muted",
									children: "Sixteen articles. Members hold the first six, staff the next five, managers the last five. The owner sits above managers, answers an appeal about a manager, and is still bound by the safety rules. Rank never outranks Article 14."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-muted",
									children: [
										visibleArticles.length,
										" of ",
										articles.length,
										" articles",
										needle ? " match your search" : "",
										"."
									]
								}),
								visibleArticles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-8 rounded-2xl border border-line bg-surface px-5 py-8 text-muted",
									children: [
										"No article matches “",
										query.trim(),
										"”. Try member, staff, appeal, or manager."
									]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 space-y-10",
									children: articleRoles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs tracking-widest text-mist uppercase",
										children: role
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 space-y-8",
										children: visibleArticles.filter((article) => article.role === role).map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
											id: article.id,
											className: "scroll-mt-24",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "font-display text-2xl text-fg",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: `#${article.id}`,
													className: "text-base text-peach",
													children: ["Art. ", article.n]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block",
													children: article.title
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-muted",
												children: article.body
											})]
										}, article.id))
									})] }, role))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "terms",
							className: "mt-16",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-3xl text-fg",
									children: "Terms and conditions"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-muted",
									children: "These terms cover membership in the Chillora Discord. They are not a contract with Discord Inc., and they are not legal advice. Discord’s Terms of Service and Community Guidelines still apply, and they win if something here conflicts with them."
								}),
								visibleTerms.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-8 text-muted",
									children: "No term matches that search."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 space-y-8",
									children: visibleTerms.map((term) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
										id: term.id,
										className: "scroll-mt-24",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
											className: "flex items-baseline gap-3 font-display text-2xl text-fg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base text-peach",
												children: term.n
											}), term.title]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 space-y-3",
											children: term.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-muted",
												children: paragraph
											}, paragraph))
										})]
									}, term.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "enforcement",
							className: "mt-16",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
										className: "h-5 w-5 text-moon",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-3xl text-fg",
										children: "Enforcement"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-muted",
									children: "Most first misses start at a reminder. Staff can skip steps when the harm is already done. Context matters: a raid, a repeat, or a threat is not treated like a misplaced meme."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "mt-6 space-y-5",
									children: ladder.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-surface-2 font-display text-sm text-moon ring-1 ring-line",
											children: step.n
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-medium text-fg",
											children: step.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-muted",
											children: step.body
										})] })]
									}, step.n))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 rounded-2xl border border-line bg-surface px-5 py-5 sm:px-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-medium text-peach",
										children: "Straight to a ban"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-muted",
										children: "Doxxing, sexual content involving a minor, raids, malware, credible threats, and ban evasion skip the ladder. Those accounts are removed and reported when Discord or the law requires it. There is no public argument afterward."
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							id: "contact",
							className: "mt-16 rounded-3xl border border-line bg-surface px-5 py-8 sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {
										className: "h-5 w-5 text-moon",
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-3xl text-fg",
										children: "Contact"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-2xl text-muted",
									children: "Questions about a punishment, or about these terms, go to a moderator inside the server. Ask once, in private. This page is the public copy of the charter."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 flex flex-col gap-3 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: DISCORD_URL,
										target: "_blank",
										rel: "noreferrer",
										className: "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-peach px-5 text-sm font-medium text-bg",
										children: [
											"discord.gg/",
											INVITE_CODE,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
												className: "h-4 w-4",
												"aria-hidden": "true"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: copyInvite,
										className: "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line px-5 text-sm text-fg",
										children: copied === "done" ? "Copied" : copied === "failed" ? "Use the link" : "Copy link"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
							className: "mt-12 border-t border-line pt-6 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Chillora is an independent Discord community and is not affiliated with Discord Inc. These rules are the community’s own. They don’t replace Discord’s Terms of Service." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2",
								children: [
									"Charter ",
									"1.1",
									" · Effective ",
									EFFECTIVE
								]
							})]
						})
					]
				})]
			})
		]
	});
}
var SplitComponent = CharterPage;
//#endregion
export { SplitComponent as component };
