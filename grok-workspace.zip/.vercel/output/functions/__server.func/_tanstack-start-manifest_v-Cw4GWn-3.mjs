//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cw4GWn-3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B1w3L7Fh.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B1w3L7Fh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BVk5J_nO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
