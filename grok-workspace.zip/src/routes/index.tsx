import { createFileRoute } from "@tanstack/react-router";
import { CharterPage } from "@/components/charter-page";

export const Route = createFileRoute("/")({ component: CharterPage });
