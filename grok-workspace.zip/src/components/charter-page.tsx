import { useEffect, useMemo, useState } from "react";
import {
  ArrowUpRight,
  Check,
  Copy,
  Link2,
  Moon,
  Search,
  Shield,
  Users,
} from "lucide-react";
import logoUrl from "@/assets/chillora-logo.jpg";
import {
  DISCORD_URL,
  EFFECTIVE,
  INVITE_CODE,
  VERSION,
  articles,
  ladder,
  rules,
  spirit,
  terms,
  toc,
} from "@/lib/charter";

function useActiveSection(ids: string[]) {
  const [active, setActive] = useState(ids[0] ?? "");

  useEffect(() => {
    const nodes = ids
      .map((id) => document.getElementById(id))
      .filter((node): node is HTMLElement => node !== null);
    if (nodes.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0.15, 0.4] },
    );

    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, [ids]);

  return active;
}

const sectionIds = toc.map((item) => item.id);

export function CharterPage() {
  const [query, setQuery] = useState("");
  const [copied, setCopied] = useState<"idle" | "done" | "failed">("idle");
  const active = useActiveSection(sectionIds);
  const needle = query.trim().toLowerCase();

  const visibleRules = useMemo(() => {
    if (!needle) return rules;
    return rules.filter((rule) =>
      `${rule.n} ${rule.group} ${rule.title} ${rule.body}`.toLowerCase().includes(needle),
    );
  }, [needle]);

  const visibleTerms = useMemo(() => {
    if (!needle) return terms;
    return terms.filter((term) =>
      `${term.title} ${term.paragraphs.join(" ")}`.toLowerCase().includes(needle),
    );
  }, [needle]);

  const visibleArticles = useMemo(() => {
    if (!needle) return articles;
    return articles.filter((article) =>
      `${article.n} ${article.role} ${article.title} ${article.body}`.toLowerCase().includes(needle),
    );
  }, [needle]);

  const articleRoles = useMemo(() => {
    const order: string[] = [];
    for (const article of visibleArticles) {
      if (!order.includes(article.role)) order.push(article.role);
    }
    return order;
  }, [visibleArticles]);

  const groups = useMemo(() => {
    const order: string[] = [];
    for (const rule of visibleRules) {
      if (!order.includes(rule.group)) order.push(rule.group);
    }
    return order;
  }, [visibleRules]);

  async function copyInvite() {
    let ok = false;
    try {
      await navigator.clipboard.writeText(DISCORD_URL);
      ok = true;
    } catch {
      const field = document.createElement("textarea");
      field.value = DISCORD_URL;
      field.setAttribute("readonly", "");
      field.style.position = "fixed";
      field.style.left = "0";
      field.style.top = "0";
      field.style.opacity = "0";
      document.body.appendChild(field);
      field.focus();
      field.select();
      try {
        ok = document.execCommand("copy");
      } catch {
        ok = false;
      }
      field.remove();
    }
    setCopied(ok ? "done" : "failed");
    window.setTimeout(() => setCopied("idle"), 2000);
  }

  return (
    <div className="min-h-screen bg-bg text-fg">
      <a
        href="#spirit"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-surface focus:px-4 focus:py-2"
      >
        Skip to the charter
      </a>

      <header className="sticky top-0 z-30 border-b border-line bg-bg/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
          <a href="#top" className="flex min-w-0 items-center gap-3">
            <img
              src={logoUrl}
              alt=""
              className="h-10 w-10 rounded-full object-cover ring-1 ring-line"
            />
            <span className="truncate font-display text-lg text-fg">Chillora</span>
          </a>

          <nav className="ml-auto hidden items-center gap-1 lg:flex" aria-label="On this page">
            {toc.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                className={`rounded-full px-3 py-2 text-sm ${
                  active === item.id ? "bg-surface-2 text-fg" : "text-muted hover:text-fg"
                }`}
                aria-current={active === item.id ? "true" : undefined}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noreferrer"
            className="ml-auto inline-flex h-11 items-center gap-2 rounded-full bg-peach px-4 text-sm font-medium text-bg lg:ml-3"
          >
            Join
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>

        <nav
          className="flex gap-2 overflow-x-auto px-4 pb-3 lg:hidden"
          aria-label="On this page"
        >
          {toc.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className={`shrink-0 rounded-full border px-3 py-2 text-sm ${
                active === item.id
                  ? "border-moon bg-surface-2 text-fg"
                  : "border-line text-muted"
              }`}
            >
              {item.label}
            </a>
          ))}
        </nav>
      </header>

      <main id="top" className="mx-auto grid max-w-6xl gap-10 px-4 py-8 sm:px-6 sm:py-12 lg:grid-cols-12 lg:gap-14 lg:py-16">
        <aside className="hidden lg:col-span-3 lg:block">
          <div className="sticky top-24">
            <p className="text-xs tracking-widest text-moon uppercase">On this page</p>
            <ol className="mt-4 space-y-1 border-l border-line">
              {toc.map((item) => (
                <li key={item.id}>
                  <a
                    href={`#${item.id}`}
                    className={`block border-l-2 py-2 pl-4 text-sm ${
                      active === item.id
                        ? "-ml-px border-peach text-fg"
                        : "border-transparent text-muted hover:text-fg"
                    }`}
                    aria-current={active === item.id ? "location" : undefined}
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ol>
            <p className="mt-8 text-sm text-muted">
              Version {VERSION}
              <br />
              {EFFECTIVE}
            </p>
          </div>
        </aside>

        <div className="min-w-0 lg:col-span-9">
          <header className="night-mast rounded-3xl border border-line bg-bg-soft px-5 py-8 sm:px-8 sm:py-10">
            <div className="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
              <img
                src={logoUrl}
                alt="Chillora — crescent moon over clouds"
                className="w-40 rounded-3xl ring-1 ring-line sm:w-48"
              />
              <div className="min-w-0">
                <p className="text-xs tracking-widest text-moon uppercase">
                  Discord community charter
                </p>
                <h1 className="mt-2 font-display text-4xl leading-none text-fg sm:text-5xl">
                  Rules <span className="text-peach italic">&</span> terms
                </h1>
                <p className="mt-4 max-w-xl text-base text-muted sm:text-lg">
                  The house rules for Chillora. Joining the server, or staying in it,
                  means you have read this and agree to it.
                </p>
                <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                  <a
                    href={DISCORD_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-peach px-5 text-sm font-medium text-bg"
                  >
                    Join the server
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>
                  <button
                    type="button"
                    onClick={copyInvite}
                    className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-surface px-5 text-sm text-fg"
                  >
                    {copied === "done" ? (
                      <Check className="h-4 w-4 text-moon" aria-hidden="true" />
                    ) : (
                      <Copy className="h-4 w-4 text-moon" aria-hidden="true" />
                    )}
                    {copied === "done"
                      ? "Invite copied"
                      : copied === "failed"
                        ? "Copy blocked"
                        : "Copy invite"}
                  </button>
                </div>
              </div>
            </div>
            <p className="mt-8 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted">
              <span>Effective {EFFECTIVE}</span>
              <span>Version {VERSION}</span>
              <span className="font-medium text-mist">{INVITE_CODE}</span>
            </p>
          </header>

          <section id="spirit" className="mt-12">
            <div className="flex items-center gap-3">
              <Moon className="h-5 w-5 text-moon" aria-hidden="true" />
              <h2 className="font-display text-3xl text-fg">The spirit</h2>
            </div>
            <p className="mt-3 max-w-2xl text-muted">
              Chillora works when people act like guests in a quiet room. The numbered
              rules below are how we enforce that. These four lines are the reason they exist.
            </p>
            <ul className="mt-6 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
              {spirit.map((line) => (
                <li key={line} className="px-5 py-4 text-fg sm:px-6">
                  {line}
                </li>
              ))}
            </ul>
          </section>

          <section id="rules" className="mt-14">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h2 className="font-display text-3xl text-fg">Server rules</h2>
                <p className="mt-2 text-muted">
                  {visibleRules.length} of {rules.length} rules
                  {needle ? " match your search" : ", in the order staff cite them"}.
                </p>
              </div>
              <label className="relative block w-full sm:w-72">
                <span className="sr-only">Search rules and terms</span>
                <Search
                  className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted"
                  aria-hidden="true"
                />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search voice, ban, promo…"
                  className="h-11 w-full rounded-full border border-line bg-surface pr-4 pl-10 text-sm text-fg placeholder:text-muted"
                />
              </label>
            </div>

            {visibleRules.length === 0 ? (
              <p className="mt-8 rounded-2xl border border-line bg-surface px-5 py-8 text-muted">
                Nothing in the rules matches “{query.trim()}”. Try voice, ban, scam, or promo.
              </p>
            ) : (
              <div className="mt-8 space-y-10">
                {groups.map((group) => (
                  <div key={group}>
                    <h3 className="text-xs tracking-widest text-mist uppercase">{group}</h3>
                    <ol className="mt-3 divide-y divide-line border-t border-line">
                      {visibleRules
                        .filter((rule) => rule.group === group)
                        .map((rule) => (
                          <li id={rule.id} key={rule.id} className="flex gap-4 py-5">
                            <a
                              href={`#${rule.id}`}
                              className="w-12 shrink-0 font-display text-xl text-moon"
                              aria-label={`Rule ${rule.n}`}
                            >
                              {rule.n}
                            </a>
                            <div className="min-w-0">
                              <h4 className="text-lg font-medium text-fg">{rule.title}</h4>
                              <p className="mt-2 text-muted">{rule.body}</p>
                            </div>
                          </li>
                        ))}
                    </ol>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section id="rights" className="mt-16">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-moon" aria-hidden="true" />
              <h2 className="font-display text-3xl text-fg">Rights</h2>
            </div>
            <p className="mt-3 max-w-2xl text-muted">
              Sixteen articles. Members hold the first six, staff the next five,
              managers the last five. The owner sits above managers, answers an
              appeal about a manager, and is still bound by the safety rules.
              Rank never outranks Article 14.
            </p>
            <p className="mt-2 text-sm text-muted">
              {visibleArticles.length} of {articles.length} articles
              {needle ? " match your search" : ""}.
            </p>

            {visibleArticles.length === 0 ? (
              <p className="mt-8 rounded-2xl border border-line bg-surface px-5 py-8 text-muted">
                No article matches “{query.trim()}”. Try member, staff, appeal, or manager.
              </p>
            ) : (
              <div className="mt-8 space-y-10">
                {articleRoles.map((role) => (
                  <div key={role}>
                    <h3 className="text-xs tracking-widest text-mist uppercase">{role}</h3>
                    <div className="mt-4 space-y-8">
                      {visibleArticles
                        .filter((article) => article.role === role)
                        .map((article) => (
                          <article id={article.id} key={article.id} className="scroll-mt-24">
                            <h4 className="font-display text-2xl text-fg">
                              <a href={`#${article.id}`} className="text-base text-peach">
                                Art. {article.n}
                              </a>
                              <span className="mt-1 block">{article.title}</span>
                            </h4>
                            <p className="mt-3 text-muted">{article.body}</p>
                          </article>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section id="terms" className="mt-16">
            <h2 className="font-display text-3xl text-fg">Terms and conditions</h2>
            <p className="mt-3 max-w-2xl text-muted">
              These terms cover membership in the Chillora Discord. They are not a
              contract with Discord Inc., and they are not legal advice. Discord’s
              Terms of Service and Community Guidelines still apply, and they win if
              something here conflicts with them.
            </p>

            {visibleTerms.length === 0 ? (
              <p className="mt-8 text-muted">No term matches that search.</p>
            ) : (
              <div className="mt-8 space-y-8">
                {visibleTerms.map((term) => (
                  <article id={term.id} key={term.id} className="scroll-mt-24">
                    <h3 className="flex items-baseline gap-3 font-display text-2xl text-fg">
                      <span className="text-base text-peach">{term.n}</span>
                      {term.title}
                    </h3>
                    <div className="mt-3 space-y-3">
                      {term.paragraphs.map((paragraph) => (
                        <p key={paragraph} className="text-muted">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>

          <section id="enforcement" className="mt-16">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-moon" aria-hidden="true" />
              <h2 className="font-display text-3xl text-fg">Enforcement</h2>
            </div>
            <p className="mt-3 max-w-2xl text-muted">
              Most first misses start at a reminder. Staff can skip steps when the
              harm is already done. Context matters: a raid, a repeat, or a threat
              is not treated like a misplaced meme.
            </p>
            <ol className="mt-6 space-y-5">
              {ladder.map((step) => (
                <li key={step.n} className="flex gap-4">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-surface-2 font-display text-sm text-moon ring-1 ring-line">
                    {step.n}
                  </span>
                  <div>
                    <h3 className="text-lg font-medium text-fg">{step.title}</h3>
                    <p className="mt-1 text-muted">{step.body}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-6 rounded-2xl border border-line bg-surface px-5 py-5 sm:px-6">
              <h3 className="font-medium text-peach">Straight to a ban</h3>
              <p className="mt-2 text-muted">
                Doxxing, sexual content involving a minor, raids, malware, credible
                threats, and ban evasion skip the ladder. Those accounts are removed
                and reported when Discord or the law requires it. There is no public
                argument afterward.
              </p>
            </div>
          </section>

          <section id="contact" className="mt-16 rounded-3xl border border-line bg-surface px-5 py-8 sm:px-8">
            <div className="flex items-center gap-3">
              <Link2 className="h-5 w-5 text-moon" aria-hidden="true" />
              <h2 className="font-display text-3xl text-fg">Contact</h2>
            </div>
            <p className="mt-3 max-w-2xl text-muted">
              Questions about a punishment, or about these terms, go to a moderator
              inside the server. Ask once, in private. This page is the public copy
              of the charter.
            </p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <a
                href={DISCORD_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-peach px-5 text-sm font-medium text-bg"
              >
                discord.gg/{INVITE_CODE}
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </a>
              <button
                type="button"
                onClick={copyInvite}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line px-5 text-sm text-fg"
              >
                {copied === "done" ? "Copied" : copied === "failed" ? "Use the link" : "Copy link"}
              </button>
            </div>
          </section>

          <footer className="mt-12 border-t border-line pt-6 text-sm text-muted">
            <p>
              Chillora is an independent Discord community and is not affiliated with
              Discord Inc. These rules are the community’s own. They don’t replace
              Discord’s Terms of Service.
            </p>
            <p className="mt-2">
              Charter {VERSION} · Effective {EFFECTIVE}
            </p>
          </footer>
        </div>
      </main>
    </div>
  );
}
